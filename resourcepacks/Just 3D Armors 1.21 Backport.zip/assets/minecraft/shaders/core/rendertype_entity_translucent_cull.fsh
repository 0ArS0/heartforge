#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 lightColor;
in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * ColorModulator;

    ivec4 ich = ivec4(round(texelFetch(Sampler0, ivec2(texCoord0 * vec2(textureSize(Sampler0, 0))), 0) * 255));

    switch (ich.a) {
        case 130:
        case 155:
        case 175:
        case 200:
        case 252:
        case 254:
        case 206:
        case 207:
        case 100:
        case 50:
            break;

        case 253:
            color *= lightColor;
            break;

        default:
            color *= vertexColor;
            break;
    }

    if (color.a < 0.1) discard;
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
