# Just 3D Armors 1.21 Backport

Hi there! **Minarc** here. This file is a documentation for the most technical aspects of the ModPack, mostly for dev development.
Enjoy the Resource Pack!

# How the Resource Pack works

The Resource Pack uses:
- `EMF`: Defines the new armor shape for all the mobs and the player.
    - The *inner* files specify the leggings shape. Every mob (and the player) have the same model.
    - The *outer* files the rest of the pieces. Every mob (and the player) have the same model.
    - The files with *slim* on it apply for slim models. This are a copy of the normal model.
- `CIT Resewn`: Assigns correctly the models and texture_layers. **This only applies for human armors!** The others use the default system of replacing with the same file name on the model as item ID.
    - Assigns the model in hand and menu with `type=item`.
    - Assigns the texture for wearing the armor with `type=armor`.
    - It also changes the model or texture_layer if it's enchanted. 
- `CITResewnNeoPatcher`: Patch with Sinytra Connector (**NeoForge Only**).
- `Punchy!`: Custom positions in hand (but also default better animations).

This Resource Pack also include the files for the copper armor or the nautilus armor, so if you add a backport mod such as `Copper Age Backport` or `Vanilla Backport` it'll work as well as the newer versions!