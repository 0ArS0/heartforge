This texture pack was made by wyv and is only officially available on Planet Minecraft and Modrinth:
- https://www.planetminecraft.com/texture-pack/action-s-amp-stuff-pumpkin-java-no-blur
- https://modrinth.com/resourcepack/actions-and-stuff-pumpkins

This is a derivative work of Actions & Stuff by Orevillestudios.

Uploading this pack to any website or app not listed above may result in a DMCA takedown.

All rights reserved.
