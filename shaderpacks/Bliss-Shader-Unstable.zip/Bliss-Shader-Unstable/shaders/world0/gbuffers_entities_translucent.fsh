#version 120

#define ENTITIES_TRANSLUCENT
#define ENTITIES
#define OVERWORLD_SHADER

#include "/dimensions/all_translucent.fsh"